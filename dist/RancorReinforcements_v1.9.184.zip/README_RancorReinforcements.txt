Rancor Reinforcements v1.9.184
Dragon's Dogma 2 - REFramework script

WHAT IT DOES
  During Rancor fights, the big wave enemies the game is about to spawn can be replaced by bosses.
  They are spawned by the Rancor itself, so they count toward clearing the wave.

  Wave pool (one weighted pick per big-enemy slot; 2 reinforcements per regular Rancor, 3 per Virulent
  or Devouring one):
    Griffin (Norgan), Medusa (with her pillar), Gagana, Nasty Dragon, Brine Minotaur, Brine Ogre,
    Brine Golem (regular Rancors only), Brine Cyclops
    Brine Skeleton Lord / Brine Lich replace a Skeleton Lord / Norgan Lich half the time.
  Regular Rancor final boss (the ice dragon's slot):
    Brine Drake 33%, Brine Dullahan 33%, ice dragon 33%
  Virulent Rancor final boss:
    Evil Eye, Brine Drake, Brine Sphinx, Vermund Purgener - 25% each (the ice dragon never stays)
  Devouring Rancor final boss:
    Sacred Arbor Purgener takes the dragon-carcass / Death finale 33% of the time.
  Satanica's own event and story / quest fights are never touched.

  The Evil Eye brings its swarm: while it lives every small Rancor enemy becomes one of its eyeball
  minions, its own summons and ground tentacles work inside the Rancor, and they all die with it.

REQUIREMENT
  REFramework for Dragon's Dogma 2 (latest build).

INSTALL
  Copy the "reframework" folder from this archive into your Dragon's Dogma 2 game folder
  (the folder that contains DD2.exe). You should end up with:
    <Dragons Dogma 2>\reframework\autorun\RancorReinforcements.lua
  Updating: overwrite the old RancorReinforcements.lua. Your settings are kept.

SETTINGS
  In game press Insert (REFramework menu) > Script Generated UI > Rancor Reinforcements.
  Every pool member, chance, share, HP and damage multiplier can be changed there.
  Settings are saved to <Dragons Dogma 2>\reframework\data\RancorReinforcements.json

UNINSTALL
  Delete reframework\autorun\RancorReinforcements.lua (and optionally RancorReinforcements.json
  in reframework\data).

SOURCE
  https://github.com/Pluralmite/RancorReinforcements
